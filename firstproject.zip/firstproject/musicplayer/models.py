from django.db import models
import random
def gen_random():
    code = " "
    for i in range(6):
        code+= random.randint(1,9)
    return code
# Create your models here.
class Room(models.Model):
    code = models.CharField(max_length= 8, default = gen_random , unique= True)
    host = models.CharField(max_length= 14, default= "Host", unique= True)
    guest_pause = models.BooleanField(default=False, null=False)
    vote_skip = models.IntegerField(default= 1, null=False)
    created_at = models.DateTimeField(auto_now_add=False)
