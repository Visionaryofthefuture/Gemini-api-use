import random
def gen_random():
    code = " "
    for i in range(6):
        code+= str(random.randint(1,9))
    return code
k = gen_random()
print(k)